﻿namespace Oasp4Net.Business.Service.InvitedGuestService.Interface
{
    public interface IInvitedGuestService
    {
    }
}
