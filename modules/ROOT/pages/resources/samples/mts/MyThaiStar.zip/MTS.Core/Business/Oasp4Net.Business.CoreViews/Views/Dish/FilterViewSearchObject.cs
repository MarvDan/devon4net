﻿using Newtonsoft.Json;
using Oasp4Net.Business.CoreViews.Views.Common;

namespace Oasp4Net.Business.CoreViews.Views.Dish
{
    public class FilterViewSearchObject
    {
        [JsonProperty(PropertyName = "categories")]
        public CategorySearchView[] Categories { get; set; }

        [JsonProperty(PropertyName = "searchBy")]
        public string SearchBy { get; set; }

        [JsonProperty(PropertyName = "sort")]
        public SortByView[] sort { get; set; }

        [JsonProperty(PropertyName = "maxPrice")]
        public string MaxPrice { get; set; }

        [JsonProperty(PropertyName = "minLikes")]
        public string MinLikes { get; set; }
    }
}
