﻿using Newtonsoft.Json;

namespace Oasp4Net.Business.CoreViews.Views.Common
{
    public class SortByView
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        ///  ASC for ascending and DESC for descending
        /// </summary>
        [JsonProperty(PropertyName = "direction")]
        public string Direction { get; set; } 
        
    }
}