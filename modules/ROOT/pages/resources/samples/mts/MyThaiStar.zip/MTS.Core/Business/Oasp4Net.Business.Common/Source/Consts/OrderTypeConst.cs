﻿namespace Oasp4Net.Business.Common.Source.Consts
{
    public class OrderTypePrefixConst
    {
        public const string OrderReservationPrefix = "CRS"; //Common ReServation
        public const string OrderGuestPrefix = "GRS"; //Guest ReServation
    }
}
