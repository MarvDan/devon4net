﻿using System;
using Newtonsoft.Json;

namespace Oasp4Net.Business.CoreViews.Views.Booking
{
    public class BookingView
    {
        [JsonProperty(PropertyName = "booking")]
        public BookingViewValues Booking { get; set; }

        [JsonProperty(PropertyName = "invitedGuests")]
        public Invitedguest[] InvitedGuests { get; set; }
    }

    public class BookingViewValues
    {
        [JsonProperty(PropertyName = "bookingDate")]
        public DateTime BookingDate { get; set; }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "email")]
        public string Email { get; set; }

        [JsonProperty(PropertyName = "bookingType")]
        public int BookingType { get; set; }

        [JsonProperty(PropertyName = "assistants")]
        public int Assistants { get; set; }
    }

    public class Invitedguest
    {
        [JsonProperty(PropertyName = "email")]
        public string Email { get; set; }
    }
}
