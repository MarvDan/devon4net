﻿using Newtonsoft.Json;

namespace Oasp4Net.Business.CoreViews.Views.Dish
{
    public class CategorySearchView
    {
        [JsonProperty(PropertyName = "id")]
        public long Id { get; set; }

    }
}
