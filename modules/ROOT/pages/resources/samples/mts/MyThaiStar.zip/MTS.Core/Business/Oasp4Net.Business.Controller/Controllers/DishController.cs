﻿using System;
using System.Linq;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oasp4Net.Business.CoreViews.Converters;
using Oasp4Net.Business.CoreViews.Views.Common;
using Oasp4Net.Business.CoreViews.Views.Dish;
using Oasp4Net.Business.Service.DishService.Interface;
using Oasp4Net.Infrastructure.AOP.Source.Attributes;

namespace Oasp4NetCore.Business.Controller.Controllers
{

    [EnableCors("CorsPolicy")]
    public class DishController : Microsoft.AspNetCore.Mvc.Controller
    {

        private readonly IDishService _dishService;

        public DishController(IDishService service)
        {
            _dishService = service;
        }

        /// <summary>
        /// Gets the  list of available dishes regarding the filter options
        /// </summary>
        /// <param name="filterView">Contains the criteria values to perform the search. Case of null or empty values will return the full set of dishes.</param>
        /// <returns></returns>
        /// <response code="200"> Ok. The search process has beencompleted with no error.</response>
        /// <response code="401">Unathorized. Autentication fail</response>  
        /// <response code="403">Forbidden. Authorization error.</response>    
        /// <response code="500">Internal Server Error. The search process ended with error.</response>       
        [HttpPost]
        [HttpOptions]
        [AllowAnonymous]
        [Route("/mythaistar/services/rest/Dishmanagement/v1/Dish/Search")]
        [EnableCors("CorsPolicy")]
        [Oasp4NetAopController]
        public IActionResult Search([FromBody] FilterViewSearchObject filterView)
        {
            if (filterView == null) filterView = new FilterViewSearchObject { MaxPrice = "0", MinLikes = "0", SearchBy = string.Empty, sort = new SortByView[0] };
            var categories = filterView.Categories ?? new CategorySearchView[0];
            var searchBy = filterView.SearchBy ?? string.Empty;
            var result = new ResultObjectView<DishViewResult>
            {
                Pagination =
                {
                    Page = 1,
                    Size = 500,
                    Total = null
                }
            };

            try
            {
                decimal maxPrice = string.IsNullOrEmpty(filterView.MaxPrice) ? 0 : Convert.ToDecimal(filterView.MaxPrice);
                int minLikes = string.IsNullOrEmpty(filterView.MinLikes) ? 0 : Convert.ToInt32(filterView.MinLikes);

                var dishList = _dishService.GetDishListFromFilter(false, maxPrice, Convert.ToInt32(minLikes), searchBy, categories.Select(c => c.Id).ToList(), -1).ToList();
                result.Result = dishList.Select(DishConverter.EntityToApi).ToList();
                result.Pagination.Total = dishList.Count();
                var serializerSettings = new JsonSerializerSettings
                {
                    Formatting = Formatting.None
                };
                Response.Headers.Add("Access-Control-Expose-Headers", "Authorization");
                Response.Headers.Add("X-Content-Type-Options", "nosniff");
                Response.Headers.Add("X-Frame-Options", "DENY");
                Response.Headers.Add("X-XSS-Protection", "1;mode=block");
                Response.Headers.Add("X-Application-Context", "restaurant:h2mem:8081");
                var json = JsonConvert.SerializeObject(result, serializerSettings);
                return new OkObjectResult(json);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, $"{ex.Message} : {ex.InnerException}");
            }

        }
    }
}
