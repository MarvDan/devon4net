using Microsoft.AspNetCore.Identity;

namespace Oasp4Net.Infrastructure.JWT
{
    public class ApplicationUser : IdentityUser
    {
    }
}