﻿#region using

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.PlatformAbstractions;
using Microsoft.IdentityModel.Tokens;
using Oasp4net.DataAccess.Repositories.Implementation;
using Oasp4net.DataAccess.Repositories.Interfaces;
using Oasp4net.DataAccessLayer;
using Oasp4net.DataAccessLayer.Common.Implementation;
using Oasp4net.DataAccessLayer.Common.Interfaces;
using Oasp4Net.Business.Service.BookingService.Implementation;
using Oasp4Net.Business.Service.BookingService.Interface;
using Oasp4Net.Business.Service.DishService.Implementation;
using Oasp4Net.Business.Service.DishService.Interface;
using Oasp4Net.Business.Service.InvitedGuestService.Implementation;
using Oasp4Net.Business.Service.InvitedGuestService.Interface;
using Oasp4Net.Business.Service.LoginService.Implementation;
using Oasp4Net.Business.Service.LoginService.Interface;
using Oasp4Net.Business.Service.OrderDishExtraIngredientService.Implementation;
using Oasp4Net.Business.Service.OrderDishExtraIngredientService.Interface;
using Oasp4Net.Business.Service.OrderLineService.Implementation;
using Oasp4Net.Business.Service.OrderLineService.Interface;
using Oasp4Net.Business.Service.OrderService.Implementation;
using Oasp4Net.Business.Service.OrderService.Interface;
using Oasp4Net.Infrastructure.AOP.Source.Attributes;
using Oasp4Net.Infrastructure.JWT;
using Oasp4Net.Infrastructure.JWT.Data;
using Swashbuckle.AspNetCore.Swagger;

#endregion

namespace Oasp4Net.Application.WebApi
{
    public class Startup
    {
        private static string AppPath = Directory.GetCurrentDirectory() + @"\Application\WebApi\";        
        public IConfiguration Configuration { get; set; }
        private const string CorsPolicy = "CorsPolicy";
        private readonly SymmetricSecurityKey _signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtConst.Secret));

        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(AppPath)
                .AddJsonFile("appsettings.json", false, true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", true)
                .AddEnvironmentVariables();
            Configuration = builder.Build();
        }
        
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            ConfigureDbService(ref services);
            ConfigureDIService(ref services);
            ConfigureCorsService(ref services);
            ConfigureJwtService(ref services);
            ConfigureSwaggerService(ref services);
            services.AddMvc().AddJsonOptions(options => options.SerializerSettings.ReferenceLoopHandling =
                Newtonsoft.Json.ReferenceLoopHandling.Ignore);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, DataSeeder seeder)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();
            loggerFactory.AddFile($"{AppPath}/{Configuration["LogFile"]}");

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseBrowserLink();
            }
            app.UseStaticFiles();
            app.UseAuthentication();

            ConfigureCorsApp(ref app);
            ConfigureSwaggerApp(ref app);
            seeder.SeedAsync().Wait();
            app.UseMvc();
        }

        #region swagger

        private void ConfigureSwaggerService(ref IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "OASP4NET API",
                    Description = "A simple example ASP.NET Core Web API",
                    TermsOfService = "None",
                    Contact = new Contact { Name = "jmsanchez", Email = "", Url = "" },
                    License = new License { Name = "Use under OSS", Url = "" }
                });

                foreach (var doc in GetXmlDocumentsForSwagger())
                    c.IncludeXmlComments(GetXmlCommentsPath(doc));
            });
            services.AddMvcCore().AddApiExplorer();
        }


        private void ConfigureSwaggerApp(ref IApplicationBuilder app)
        {
            app.UseStaticFiles();
            app.UseMvcWithDefaultRoute();
            app.UseSwagger();
            app.UseSwaggerUI(c => { c.SwaggerEndpoint("/swagger/v1/swagger.json", "V1 Docs"); });
        }


        private List<string> GetXmlDocumentsForSwagger()
        {
            var basePath = PlatformServices.Default.Application.ApplicationBasePath;
            return Directory.GetFiles(basePath, "*.Swagger.xml", SearchOption.AllDirectories).ToList();
        }
        #endregion

        #region DI configuration

        /// <summary>
        /// Transient lifetime services are created each time they are requested. This lifetime works best for lightweight, stateless services.
        /// Scoped lifetime services are created once per request.
        /// Singleton lifetime services are created the first time they are requested (or when ConfigureServices is run if you specify an instance there) and then every subsequent request will use the same instance.
        /// </summary>
        /// <param name="services"></param>
        private void ConfigureDIService(ref IServiceCollection services)
        {
            services.AddTransient<DataSeeder>();
            services.AddIdentity<ApplicationUser, IdentityRole>().AddEntityFrameworkStores<AuthContext>().AddDefaultTokenProviders();

            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
            services.AddScoped(typeof(IUnitOfWork), typeof(UnitOfWork));
            services.AddScoped<Oasp4NetAopControllerAttribute>();

            //services
            services.AddTransient<IDishService, DishService>();
            services.AddTransient<ILoginService, LoginService>();
            services.AddTransient<IBookingService, BookingService>();
            services.AddTransient<IOrderService, OrderService>();
            services.AddTransient<IOrderLineService, OrderLineService>();
            services.AddTransient<IInvitedGuestService, InvitedGuestService>();
            services.AddTransient<IOrderDishExtraIngredientService, OrderDishExtraIngredientService>();

            //Repositories
            services.AddTransient<IOrderLineRepository, OrderLineRepository>();
            services.AddTransient<IBookingRepository, BookingRepository>();
            services.AddTransient<IDishRepository, DishRepository>();
        }

        #endregion

        #region cors configuration

        private void ConfigureCorsService(ref IServiceCollection services)
        {
            //enables CORS and httpoptions
            services.AddCors(options =>
            {
                options.AddPolicy(CorsPolicy, builder =>
                {
                    builder.AllowAnyOrigin();
                    builder.AllowAnyHeader();
                    builder.AllowAnyMethod();
                    builder.AllowCredentials();
                });
            });
        }

        private void ConfigureCorsApp(ref IApplicationBuilder app)
        {
            app.UseCors(CorsPolicy);
        }

        #endregion

        #region JWT configuration

        private void ConfigureJwtService(ref IServiceCollection services)
        {

            services.AddAuthorization(options =>
            {
                options.AddPolicy("MTSWaiterPolicy", policy => policy.RequireClaim("MTSWaiter", "waiter"));
                options.AddPolicy("MTSCustomerPolicy", policy => policy.RequireClaim("MTSCustomer", "customer"));
            });

            services.AddAuthentication()
                .AddJwtBearer(cfg =>
                {
                    cfg.RequireHttpsMetadata = false;
                    cfg.SaveToken = true;
                    cfg.TokenValidationParameters = GetTokenValidationParameters();
                });

            services.Configure<JwtOptions>(options =>
            {
                options.Issuer = JwtConst.Issuer;
                options.Audience = JwtConst.Issuer;
                options.SigningCredentials = new SigningCredentials(_signingKey, SecurityAlgorithms.HmacSha512);
            });
        }

        private TokenValidationParameters GetTokenValidationParameters()
        {
            //Jwt decode
            var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtConst.Secret));
            return new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = JwtConst.Issuer,

                ValidateAudience = true,
                ValidAudience = $"http://localhost:{Configuration["LocalListenPort"]}",

                ValidateIssuerSigningKey = true,
                IssuerSigningKey = signingKey,

                RequireExpirationTime = true,
                ValidateLifetime = true,

                ClockSkew = TimeSpan.Zero
            };
        }

        #endregion

        #region database
        /// <summary>
        /// AddDbContextPool .net core 2 boost performance
        /// </summary>
        /// <param name="services"></param>
        private void ConfigureDbService(ref IServiceCollection services)
        {

            services.AddDbContext<ModelContext>(
                options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            //auth4jwt
            services.AddDbContext<AuthContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("AuthConnection")));
        }

        #endregion

        #region private methods
        private static string GetXmlCommentsPath(string assemblyName)
        {
            var basePath = PlatformServices.Default.Application.ApplicationBasePath;
            return Path.Combine(basePath, assemblyName);
        }
        #endregion
    }

}
