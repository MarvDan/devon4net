﻿namespace Oasp4Net.Business.Service.OrderLineService.Interface
{
    public interface IOrderLineService
    {
    }
}
