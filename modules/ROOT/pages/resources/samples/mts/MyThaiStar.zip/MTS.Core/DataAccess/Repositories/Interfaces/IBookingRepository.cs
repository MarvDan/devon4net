﻿using System.Collections.Generic;
using Oasp4net.DataAccessLayer.Common.Interfaces;
using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Business.Common.Source.Enums;

namespace Oasp4net.DataAccess.Repositories.Interfaces
{
    public interface IBookingRepository : IRepository<Booking>
    {
        OrderTypeEnum GetType(string bookingToken);
        Booking GetBooking(string bookingToken);
        List<Booking> GetBookingList(string bookingToken);
    }
}
