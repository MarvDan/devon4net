﻿using Oasp4net.DataAccessLayer.Common.Implementation;
using Oasp4net.DataAccessLayer.Common.Interfaces;
using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Business.Service.OrderLineService.Interface;

namespace Oasp4Net.Business.Service.OrderLineService.Implementation
{
    public class OrderLineService : EntityService<OrderLine>, IOrderLineService
    {
        protected OrderLineService(IUnitOfWork unitOfWork, IRepository<OrderLine> repository) : base(unitOfWork, repository)
        {
        }
    }
}
