﻿using System;
using System.Collections.Generic;
using System.Linq;
using Oasp4net.DataAccess.Repositories.Interfaces;
using Oasp4net.DataAccessLayer.Common.Implementation;
using Oasp4net.DataAccessLayer.Common.Interfaces;
using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Business.Service.DishService.Interface;

namespace Oasp4Net.Business.Service.DishService.Implementation
{
    public class DishService: EntityService<Dish>, IDishService
    {
        //private readonly IUnitOfWork _unitOfWork;
        private readonly IDishRepository _repository;
        private readonly IRepository<Category> _categoryRepository;
        private readonly IRepository<DishCategory> _dishCategoryRepository;
        private readonly IRepository<DishIngredient> _dishIngredientRepository;
        private readonly IRepository<Ingredient> _ingredientRepository;
        private readonly IRepository<Image> _imageRepository;

        public DishService(IUnitOfWork unitOfWork, IDishRepository repository, IRepository<Category> categoryRepository, IRepository<DishCategory> dishcCategoryRepository, IRepository<DishIngredient> dishIngredientRepository, IRepository<Ingredient> ingredientRepository, IRepository<Image> imageRepository) : base(unitOfWork, repository)
        {
            //_unitOfWork = unitOfWork;
            _repository = repository;
            _categoryRepository = categoryRepository;
            _dishCategoryRepository = dishcCategoryRepository;
            _dishIngredientRepository = dishIngredientRepository;
            _ingredientRepository = ingredientRepository;
            _imageRepository = imageRepository;
        }

        public List<Dish> GetDishListFromFilter(bool isFav, decimal maxPrice, int minLikes, string searchBy, List<long> categoryIdList, long userId)
        {
            var result = _repository.GetAll();

            if (isFav && userId >= 0)
            {
                var dishes = _repository.GetAll(u => u.Id == userId).FirstOrDefault();
                if (dishes != null)
                {
                    var favourites = dishes.UserFavourite.Select(f => f.Id).ToList();
                    if (favourites.Any()) result = result.Where(r => favourites.Contains(r.Id));
                }
            }

            if (categoryIdList.Any())
            {
                result = result.Where(r => r.DishCategory.Any(a => categoryIdList.Contains(a.Id)));
            }

            if (!string.IsNullOrEmpty(searchBy))
            {
                var criteria = searchBy.ToLower();
                result = result.Where(d => d.Name.ToLower().Contains(criteria) || d.Description.ToLower().Contains(criteria));
            }

            //todo twitter
            if (minLikes > 0)
            {

            }

            if (maxPrice > 0)
            {
                result = result.Where(r => r.Price <= maxPrice);
            }

            PopulateDishReferences(ref result);
            
            return result.ToList();
        }

        #region private methods

        private void PopulateDishReferences(ref IEnumerable<Dish> dishList)
        {
            foreach (var dish in dishList)
            {
                dish.DishCategory = PopulateDishCategories(dish.Id);
                dish.DishIngredient = PopulateDishIngredient(dish.Id);
                dish.IdImageNavigation = PopulateDishImage(dish.IdImage);
            }
        }

        private Image PopulateDishImage(long? dishIdImage)
        {
            return _imageRepository.Get(i => i.Id == dishIdImage);
        }

        private ICollection<DishIngredient> PopulateDishIngredient(long dishId)
        {
            try
            {
                var dishIngredients = _dishIngredientRepository.GetAll(c => c.IdDish == dishId);

                if (dishIngredients == null || !dishIngredients.Any()) return new List<DishIngredient>();

                foreach (var ingredient in dishIngredients)
                {
                    ingredient.IdIngredientNavigation = _ingredientRepository.Get(c => c.Id == ingredient.IdIngredient);
                }

                return dishIngredients.ToList();
            }
            catch (Exception ex)
            {
                var msg = $"{ex.Message} : {ex.InnerException}";
                return new List<DishIngredient>();
            }
        }

        private ICollection<DishCategory> PopulateDishCategories(long dishId)
        {
            try
            {
                var dishCategories = _dishCategoryRepository.GetAll(c => c.IdDish == dishId);
                if (dishCategories == null || !dishCategories.Any()) return new List<DishCategory>();

                foreach (var dishCategory in dishCategories)
                {
                    dishCategory.IdCategoryNavigation = _categoryRepository.Get(c => c.Id == dishCategory.IdCategory);
                }

                return dishCategories.ToList();
            }
            catch (Exception ex)
            {
                var msg = $"{ex.Message} : {ex.InnerException}";
                return new List<DishCategory>();
            }
        }

        #endregion
    }


}
