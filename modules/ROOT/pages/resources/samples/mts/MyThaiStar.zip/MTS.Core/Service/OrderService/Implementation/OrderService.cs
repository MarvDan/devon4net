﻿using System;
using System.Collections.Generic;
using System.Linq;
using Oasp4net.DataAccess.Repositories.Interfaces;
using Oasp4net.DataAccessLayer.Common.Implementation;
using Oasp4net.DataAccessLayer.Common.Interfaces;
using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Business.Common.Source.Enums;
using Oasp4Net.Business.CoreViews.Views.Order;
using Oasp4Net.Business.Service.OrderService.Interface;

namespace Oasp4Net.Business.Service.OrderService.Implementation
{


    public class OrderService  : EntityService<Order>, IOrderService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IBookingRepository _bookingRepository;
        private readonly IRepository<OrderLine> _orderlineRepository;
        private readonly IRepository<Order> _repository;
        private readonly IRepository<OrderDishExtraIngredient> _orderDishExtraIngredientRepository;

        public OrderService(IUnitOfWork unitOfWork, 
            IRepository<Order> repository,
            IBookingRepository bookingRepository,
            IRepository<OrderLine> orderlineRepository,
            IRepository<OrderDishExtraIngredient> orderDishExtraIngredientRepository) : base(unitOfWork, repository)
        {
            _repository = repository;
            _unitOfWork = unitOfWork;
            _bookingRepository = bookingRepository;
            _orderlineRepository = orderlineRepository;
            _orderDishExtraIngredientRepository = orderDishExtraIngredientRepository;
        }
        public void OrderTheOrder(string bookingToken, List<OrderlineView> orderLines)
        {
            var bookingtype = _bookingRepository.GetType(bookingToken);
            var booking = _bookingRepository.GetBooking(bookingToken);
            if (booking == null) throw new Exception("No booking");
            var orders = _repository.GetAll(o => o.IdReservation == booking.Id || o.IdInvitationGuest == booking.Id);
            var order = orders != null ? orders.FirstOrDefault() : new Order();

            switch (bookingtype)
            {
                case OrderTypeEnum.CommonBooking:

                    order = new Order { IdReservation = booking.Id };
                    break;
                case OrderTypeEnum.GuestBooking:
                    order = new Order { IdInvitationGuest = booking.Id };
                    break;

            }
            _repository.Create(order);
            _repository.Save();
            _unitOfWork.Commit();


            foreach (var orderItem in orderLines)
            {
                if (order == null) continue;
                var orderline = new OrderLine
                {
                    IdOrder = order.Id,
                    Amount = orderItem.orderLine.amount,
                    IdDish = orderItem.orderLine.dishId,
                    Comment = orderItem.orderLine.comment
                };

                _orderlineRepository.Create(orderline);
                _orderlineRepository.Save();
                //_unitOfWork.Commit();

                foreach (var extra in orderItem.extras)
                {

                    _orderDishExtraIngredientRepository.Create(new OrderDishExtraIngredient
                    {
                        IdIngredient = extra.id,
                        IdOrderLine = orderline.Id
                    });
                    _orderDishExtraIngredientRepository.Save();
                    _unitOfWork.Commit();

                }
            }
            _unitOfWork.Commit();
        }
    }
}
