﻿using Newtonsoft.Json;

namespace Oasp4Net.Business.CoreViews.Views.Common
{
    public class Pagination
    {
        [JsonProperty(PropertyName = "size")]
        public int Size { get; set; }
        [JsonProperty(PropertyName = "page")]
        public int Page { get; set; }
        [JsonProperty(PropertyName = "total")]
        public object Total { get; set; }
    }
}