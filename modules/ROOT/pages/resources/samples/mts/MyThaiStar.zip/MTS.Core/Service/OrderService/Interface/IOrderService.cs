﻿using System;
using System.Collections.Generic;
using System.Text;
using Oasp4Net.Business.CoreViews.Views.Order;

namespace Oasp4Net.Business.Service.OrderService.Interface
{
    public interface IOrderService
    {
        void OrderTheOrder(string bookingToken, List<OrderlineView> orderLines);
    }
}
