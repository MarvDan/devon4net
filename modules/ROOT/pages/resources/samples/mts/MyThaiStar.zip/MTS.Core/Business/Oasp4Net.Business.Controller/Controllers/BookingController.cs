﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oasp4Net.Business.CoreViews.Views.Booking;
using Oasp4Net.Business.CoreViews.Views.Common;
using Oasp4Net.Business.Service.BookingService.Interface;

namespace Oasp4NetCore.Business.Controller.Controllers
{
    [EnableCors("CorsPolicy")]
    public class BookingController : Microsoft.AspNetCore.Mvc.Controller
    {
        private readonly IBookingService _bookingService;

        public BookingController(IBookingService bookingService)
        {
            _bookingService = bookingService;
        }

        /// <summary>
        /// Method to make a reservation with potentiel guests. The method returns the reservation token with the format: {(CB_|GB_)}{now.Year}{now.Month:00}{now.Day:00}{_}{MD5({Host/Guest-email}{now.Year}{now.Month:00}{now.Day:00}{now.Hour:00}{now.Minute:00}{now.Second:00})}
        /// </summary>

        /// <param name="bookingView"></param>
        /// <response code="201">Ok.</response>
        /// <response code="400">Bad request. Parser data error.</response>
        /// <response code="401">Unathorized. Autentication fail</response>
        /// <response code="403">Forbidden. Authorization error.</response>
        /// <response code="500">Internal Server Error. The search process ended with error.</response>
        [HttpPost]
        [HttpOptions]
        [Route("/mythaistar/services/rest/bookingmanagement/v1/booking")]
        [AllowAnonymous]
        [EnableCors("CorsPolicy")]
        public IActionResult BookingBooking([FromBody]BookingView bookingView)
        {

            //var bookingRepository = new BookingRepository();

            try
            {
                var invitedGuest = bookingView.InvitedGuests?.Select(i => i.Email).ToList() ?? new List<string>();
                var booking = _bookingService.CreateReservationAndGuestList(bookingView.Booking.BookingType,
                    bookingView.Booking.Name, bookingView.Booking.Assistants, invitedGuest, bookingView.Booking.Email,
                    bookingView.Booking.BookingDate.ToLocalTime(), null);


                Console.WriteLine($"http://localhost:4200/booking/acceptInvite/{booking.BookingToken}");
                Console.WriteLine($"http://localhost:4200/booking/rejectInvite/{booking.BookingToken}");
                Console.WriteLine($"http://localhost:8081/mythaistar/services/rest/bookingmanagement/v1/booking/cancel/{booking.BookingToken}");
                var serializerSettings = new JsonSerializerSettings
                {
                    Formatting = Formatting.None
                };
                Response.Headers.Add("X-Content-Type-Options", "nosniff");
                Response.Headers.Add("X-Frame-Options", "DENY");
                Response.Headers.Add("X-XSS-Protection", "1;mode=block");
                var json = JsonConvert.SerializeObject(booking, serializerSettings);
                return new OkObjectResult(json);
            }
            catch (Exception ex)
            {
                var content = StatusCode((int)HttpStatusCode.BadRequest, $"{ex.Message} : {ex.InnerException}");
                return Content(JsonConvert.SerializeObject(content), "application/json");
            }
        }


        /// <summary>
        /// Method to get reservations
        /// </summary>
        /// <response code="201">Ok.</response>
        /// <response code="400">Bad request. Parser data error.</response>
        /// <response code="401">Unathorized. Autentication fail</response>
        /// <response code="403">Forbidden. Authorization error.</response>
        /// <response code="500">Internal Server Error. The search process ended with error.</response>
        [HttpPost]
        [Route("/mythaistar/services/rest/bookingmanagement/v1/booking/search")]
        //[Authorize(Policy = "MTSWaiterPolicy")]
        [AllowAnonymous]
        [EnableCors("CorsPolicy")]
        public IActionResult BookingSearch([FromBody]BookingSearchView bookingSearchView)
        {
            //var bookingRepository = new BookingRepository();

            try
            {
                var result = new ResultObjectView<BookingSearchResponse>
                {
                    Pagination =
                    {
                        Page = 1,
                        Size = 500,
                        Total = null
                    },
                    Result = _bookingService.GetBookingSearch(bookingSearchView.bookingToken, bookingSearchView.email)
                };

                result.Pagination.Total = result.Result != null ? result.Result.Count : 0;

                var serializerSettings = new JsonSerializerSettings
                {
                    Formatting = Formatting.None
                };

                Response.Headers.Add("X-Content-Type-Options", "nosniff");
                Response.Headers.Add("X-Frame-Options", "DENY");
                Response.Headers.Add("X-XSS-Protection", "1;mode=block");
                var json = JsonConvert.SerializeObject(result, serializerSettings);
                return new OkObjectResult(json);
            }
            catch (Exception ex)
            {
                var content = StatusCode((int)HttpStatusCode.BadRequest, $"{ex.Message} : {ex.InnerException}");
                return Content(JsonConvert.SerializeObject(content), "application/json");
            }

        }

    }
}
