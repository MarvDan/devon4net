﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace Oasp4Net.Business.CoreViews.Views.Common
{
    public class ResultObjectView<T>
    {
        [JsonProperty(PropertyName = "pagination")]
        public Pagination Pagination { get; set; }
        [JsonProperty(PropertyName = "result")]
        public List<T> Result { get; set; }

        public ResultObjectView()
        {
            Pagination = new Pagination();
            Result = new List<T>();
        }
    }
}