using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Oasp4Net.Architecture.Common.Source.Interfaces
{
    public interface IAssemblyResolver
    {
        void GetReferencedAssemblyController(string section, ref IServiceCollection services,
            IConfigurationRoot configuration);
    }
}