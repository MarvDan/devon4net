﻿
namespace Oasp4Net.Business.Service.OrderDishExtraIngredientService.Interface
{
    public interface IOrderDishExtraIngredientService
    {
    }
}
