﻿using System;
using System.Collections.Generic;
using Oasp4net.DataAccessLayer.Models;

namespace Oasp4Net.Business.Service.DishService.Interface
{
    public interface IDishService
    {
        List<Dish> GetDishListFromFilter(bool isFav, decimal maxPrice, int minLikes, string searchBy, List<long> list, long userId);
    }

}