﻿using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Business.CoreViews.Views.Order;

namespace Oasp4Net.Business.CoreViews.Converters
{
    public class ExtraIngredientonverter
    {
        public static Extra EntityToApi(OrderDishExtraIngredient item)
        {
            if (item == null) return new Extra();

            return new Extra
            {
                id = item.Id

            };

        }
    }
}
