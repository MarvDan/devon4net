﻿namespace Oasp4Net.Business.Service.LoginService.Interface
{
    public interface ILoginService
    {
        bool Login(string userName, string password);
        string GetUserScope(string userName);
    }
}
