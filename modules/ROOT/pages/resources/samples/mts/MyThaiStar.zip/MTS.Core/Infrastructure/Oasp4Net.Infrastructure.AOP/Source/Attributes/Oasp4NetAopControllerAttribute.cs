﻿using System;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Oasp4Net.Infrastructure.AOP.Source.Attributes
{
    public class Oasp4NetAopControllerAttribute : ActionFilterAttribute
    {
        public Oasp4NetAopControllerAttribute()
        {

        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            Console.WriteLine("ClassFilter OnActionExecuting");
            base.OnActionExecuting(context);
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {
            Console.WriteLine("ClassFilter OnActionExecuted");
            base.OnActionExecuted(context);
        }

        public override void OnResultExecuting(ResultExecutingContext context)
        {
            Console.WriteLine("ClassFilter OnResultExecuting");
            base.OnResultExecuting(context);
        }

        public override void OnResultExecuted(ResultExecutedContext context)
        {
            Console.WriteLine("ClassFilter OnResultExecuted");
            base.OnResultExecuted(context);
        }

    }
}
