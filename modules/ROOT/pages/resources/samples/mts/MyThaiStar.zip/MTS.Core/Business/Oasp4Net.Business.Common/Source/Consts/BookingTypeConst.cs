﻿namespace Oasp4Net.Business.Common.Source.Consts
{
    public class BookingTypeConst
    {
        public const string CommonBooking = "CB"; //Common ReServation == 0
        public const string GuestBooking = "GB"; //Guest ReServation == 1
    }
}