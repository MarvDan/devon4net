﻿using Newtonsoft.Json;
using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Business.CoreViews.Views.Booking;

namespace Oasp4Net.Business.CoreViews.Converters
{
    public class BookingConverter
    {
        public static BookingSearchResponseView EntityToApi(Booking item)
        {
            if (item == null) return new BookingSearchResponseView();

            return new BookingSearchResponseView
            {
                id = item.Id,
                bookingToken = item.ReservationToken,
                revision = null,
                modificationCounter = 0,
                name = item.Name,
                email = item.Email,
                assistants = item.Assistants,
                bookingDate = JsonConvert.SerializeObject(item.BookingDate),
                bookingType = item.IdBookingType == 0 ? "COMMON" : "INVITED",
                canceled = item.Canceled ?? false,
                comment = item.Comments,
                creationDate = JsonConvert.SerializeObject(item.CreationDate),
                expirationDate = item.ExpirationDate != null
                    ? JsonConvert.SerializeObject(item.ExpirationDate)
                    : string.Empty,
                userId = item.UserId
            };

        }

        public static BookingSearchResponseView EntityToApiFullResponse(Booking item)
        {
            if (item == null) return new BookingSearchResponseView();

            return new BookingSearchResponseView
            {
                id = item.Id,
                bookingToken = item.ReservationToken,
                revision = null,
                modificationCounter = 0,
                name = item.Name,
                email = item.Email,
                assistants = item.Assistants,
                bookingDate = JsonConvert.SerializeObject(item.BookingDate),
                bookingType = item.IdBookingType == 0 ? "COMMON" : "INVITED",
                canceled = item.Canceled ?? false,
                comment = item.Comments,
                creationDate = JsonConvert.SerializeObject(item.CreationDate),
                expirationDate = item.ExpirationDate != null
                    ? JsonConvert.SerializeObject(item.ExpirationDate)
                    : string.Empty,
                userId = item.UserId
            };

        }
    }
}
