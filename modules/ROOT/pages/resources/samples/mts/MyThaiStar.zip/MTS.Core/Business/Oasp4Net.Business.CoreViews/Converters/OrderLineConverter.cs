﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Business.CoreViews.Views.Booking;
using Oasp4Net.Business.CoreViews.Views.Order;

namespace Oasp4Net.Business.CoreViews.Converters
{
    public class OrderLineConverter
    {
        public static OrderlineFullResponse EntityToApi(OrderLine item)
        {
            if (item == null) return new OrderlineFullResponse();
            var price = item.IdDishNavigation.Price != null ? decimal.Round(item.IdDishNavigation.Price.Value, 2, MidpointRounding.AwayFromZero) : 0;
            return new OrderlineFullResponse
            {
                dish = new DishFullResponse
                {
                    id = item.IdDishNavigation.Id,
                    revision = 0,
                    modificationCounter = 0,
                    name = item.IdDishNavigation.Name,
                    description = item.IdDishNavigation.Description,
                    price = price,
                    imageId = 0
                },
                extras = item.OrderDishExtraIngredient.ToList().Select(ExtraIngredientonverter.EntityToApi).ToList(),
                orderLine = new OrderlineDetailFullResponse
                {
                    id = item.Id,
                    revision = 0,
                    modificationCounter = 0,
                    orderId = item.IdOrder,
                    amount = item.Amount ?? 0,
                    comment = item.Comment,
                    dishId = item.IdDish
                }
            };


        }
    }
}
