﻿using System;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oasp4Net.Business.CoreViews.Views.Booking;
using Oasp4Net.Business.CoreViews.Views.Common;
using Oasp4Net.Business.CoreViews.Views.Order;
using Oasp4Net.Business.Service.BookingService.Interface;
using Oasp4Net.Business.Service.OrderService.Interface;

namespace Oasp4NetCore.Business.Controller.Controllers
{
    [EnableCors("CorsPolicy")]
    public class OrderController : Microsoft.AspNetCore.Mvc.Controller
    {
        private readonly IOrderService _orderService;
        private readonly IBookingService _bookingService;
        public OrderController(IOrderService orderService, IBookingService bookingService)
        {
            _orderService = orderService;
            _bookingService = bookingService;
        }

        /// <summary>
        /// Gets the  list of available orders regarding the filter options
        /// </summary>

        /// <param name="orderFilterView">Contains the filter values to perform the search. Case of null or empty values will return the full set of orders.</param>
        /// <response code="200">Ok. The search process has beencompleted with no error.</response>
        /// <response code="401">Unathorized. Autentication fail</response>
        /// <response code="403">Forbidden. Authorization error.</response>
        /// <response code="500">Internal Server Error. The search process ended with error.</response>
        [HttpPost]
        [HttpPost]
        [HttpOptions]
        [AllowAnonymous]
        [Route("/mythaistar/services/rest/Ordermanagement/v1/order/filter")]
        [EnableCors("CorsPolicy")]
        public virtual IActionResult OrderFilter([FromBody]BookingSearchView orderFilterView)
        {
            //var bookingRepository = new BookingRepository();

            try
            {
                var result = new ResultObjectView<BookingSearchResponse>
                {
                    Pagination =
                    {
                        Page = 1,
                        Size = 500,
                        Total = null
                    },
                    Result = _bookingService.GetBookingSearch(orderFilterView.bookingToken, orderFilterView.email)
                };

                result.Pagination.Total = result.Result?.Count ?? 0;

                var serializerSettings = new JsonSerializerSettings
                {
                    Formatting = Formatting.None
                };

                Response.Headers.Add("X-Content-Type-Options", "nosniff");
                Response.Headers.Add("X-Frame-Options", "DENY");
                Response.Headers.Add("X-XSS-Protection", "1;mode=block");
                var json = JsonConvert.SerializeObject(result, serializerSettings);
                return new OkObjectResult(json);
            }
            catch (Exception ex)
            {
                var content = StatusCode((int)HttpStatusCode.BadRequest, $"{ex.Message} : {ex.InnerException}");
                return Content(JsonConvert.SerializeObject(content), "application/json");
            }
        }


        /// <summary>
        /// Order the order. Given an order view, the server side will prepare the different order lines.
        /// </summary>

        /// <param name="orderView">The model of the ordert to be processed on the server side. The InvitationToken field is mandatory.</param>
        /// <response code="201">Ok. Created. Returns the created order reference</response>
        /// <response code="400">Bad Request. No Invitation token given.</response>
        /// <response code="401">Unathorized. Autentication fail</response>
        /// <response code="403">Forbidden. Authorization error.</response>
        /// <response code="500">Internal Server Error. The search process ended with error.</response>

        [HttpPost]
        [HttpPost]
        [HttpOptions]
        [AllowAnonymous]
        [Route("/mythaistar/services/rest/ordermanagement/v1/order")]
        [EnableCors("CorsPolicy")]
        public virtual IActionResult OrderOrder([FromBody]OrderView orderView)
        {
            try
            {
                _orderService.OrderTheOrder(orderView.booking.bookingToken, orderView.orderLines);
                return Ok();
            }
            catch (Exception ex)
            {
                var content = StatusCode((int)HttpStatusCode.InternalServerError, $"{ex.Message} : {ex.InnerException}");
                return Content(JsonConvert.SerializeObject(content), "application/json");
            }
        }


        /// <summary>
        /// Gets the  list of available orders regarding the search criteria options
        /// </summary>

        /// <param name="orderSearchCriteriaView">Contains the criteria values to perform the search. Case of null or empty values will return the full set of orders.</param>
        /// <response code="200">Ok. The search process has beencompleted with no error.</response>
        /// <response code="401">Unathorized. Autentication fail</response>
        /// <response code="403">Forbidden. Authorization error.</response>
        /// <response code="500">Internal Server Error. The search process ended with error.</response>
        [HttpPost]
        [HttpOptions]
        [Route("/mythaistar/services/rest/Ordermanagement/v1/order/search")]
        [AllowAnonymous]
        [EnableCors("CorsPolicy")]
        public virtual IActionResult OrderSearch([FromBody]BookingSearchView orderSearchCriteriaView)
        {
            try
            {
                var result = new ResultObjectView<OrderSearchFullResponseView>
                {
                    Pagination =
                    {
                        Page = 1,
                        Size = 500,
                        Total = null
                    },
                    Result = _bookingService.GetBookinSearchFullResponse(orderSearchCriteriaView.bookingToken,
                        orderSearchCriteriaView.email)
                };

                result.Pagination.Total = result.Result != null ? result.Result.Count : 0;

                var serializerSettings = new JsonSerializerSettings
                {
                    Formatting = Formatting.None
                };

                Response.Headers.Add("X-Content-Type-Options", "nosniff");
                Response.Headers.Add("X-Frame-Options", "DENY");
                Response.Headers.Add("X-XSS-Protection", "1;mode=block");
                var json = JsonConvert.SerializeObject(result, serializerSettings);
                return new OkObjectResult(json);
            }
            catch (Exception ex)
            {
                var content = StatusCode((int)HttpStatusCode.BadRequest, $"{ex.Message} : {ex.InnerException}");
                return Content(JsonConvert.SerializeObject(content), "application/json");
            }
        }
    }
}
