﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace Oasp4Net.Business.CoreViews.Views.Dish
{
    public class DishViewResult
    {                			
        [JsonProperty(PropertyName = "dish")]
        public DishView dish { get; set; }

        [JsonProperty(PropertyName = "image")]
        public ImageView image { get; set; }

        [JsonProperty(PropertyName = "test")]
        public int? test { get; set; }

        /// <summary>
        /// Association from DishViewResult [simple] to ExtraView [many]
        /// </summary>
        [JsonProperty(PropertyName = "ExtraViews")]
        public ICollection<ExtraView> extras { get; set; }

        /// <summary>
        /// Association from DishViewResult [simple] to CategoryView [many]
        /// </summary>
        [JsonProperty(PropertyName = "CategoryViews")]
        public ICollection<CategoryView> categories { get; set; }



        public	DishViewResult()
        {
            extras = new HashSet<ExtraView>();
            categories = new HashSet<CategoryView>();
            
        }
    }
}

