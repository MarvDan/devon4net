﻿using Oasp4net.DataAccessLayer.Common.Implementation;
using Oasp4net.DataAccessLayer.Common.Interfaces;
using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Business.Service.OrderDishExtraIngredientService.Interface;


namespace Oasp4Net.Business.Service.OrderDishExtraIngredientService.Implementation
{
    public class OrderDishExtraIngredientService : EntityService<OrderDishExtraIngredient>, IOrderDishExtraIngredientService
    {
        public OrderDishExtraIngredientService(IUnitOfWork unitOfWork, IRepository<OrderDishExtraIngredient> repository) : base(unitOfWork, repository)
        {
        }
    }
}
