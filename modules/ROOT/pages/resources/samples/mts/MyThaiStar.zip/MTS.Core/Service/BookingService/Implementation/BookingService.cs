﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Oasp4net.DataAccess.Repositories.Interfaces;
using Oasp4net.DataAccessLayer.Common.Implementation;
using Oasp4net.DataAccessLayer.Common.Interfaces;
using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Architecture.Common.Source.Extensions;
using Oasp4Net.Business.Common.Source.Consts;
using Oasp4Net.Business.CoreViews.Converters;
using Oasp4Net.Business.CoreViews.Views.Booking;
using Oasp4Net.Business.CoreViews.Views.Email;
using Oasp4Net.Business.CoreViews.Views.Order;
using Oasp4Net.Business.Service.BookingService.Interface;

namespace Oasp4Net.Business.Service.BookingService.Implementation
{
    public class BookingService : EntityService<Booking>, IBookingService
    {
        private readonly IBookingRepository _bookingRepository;
        private readonly IRepository<Order> _orderRepository;
        private readonly IRepository<InvitedGuest> _invitedGuestRepository;
        private readonly IOrderLineRepository _orderLineRepository;
        private readonly IUnitOfWork _unitOfWork;

        public BookingService(IUnitOfWork unitOfWork,
            IBookingRepository repository,
            IRepository<Order> orderRepository,
            IRepository<InvitedGuest> invitedGuestRepository,
            IOrderLineRepository orderLineRepository) : base(unitOfWork, repository)
        {
            _unitOfWork = unitOfWork;
            _bookingRepository = repository;
            _orderRepository = orderRepository;
            _invitedGuestRepository = invitedGuestRepository;
            _orderLineRepository = orderLineRepository;
        }

        public List<BookingSearchResponse> GetBookingSearch(string bookingToken, string email)
        {
            var result = new List<BookingSearchResponse>();

            try
            {                
                var bookings = !string.IsNullOrEmpty(bookingToken) ? _bookingRepository.GetBookingList(bookingToken) : _bookingRepository.GetAll().ToList();
                if (!string.IsNullOrEmpty(email)) bookings = bookings.Where(b => b.Email.Contains(email)).ToList();

                foreach (var booking in bookings)
                {
                    var orders = GetBookingOrder(booking.Id);
                    var invitedList = GetInvited(booking.Id);
                    result.Add(new BookingSearchResponse
                    {
                        booking = BookingConverter.EntityToApi(booking),
                        invitedGuests = invitedList.Select(InvitedGuestConverter.EntityToApi).ToList(),
                        orders = booking.Order != null
                            ? orders.Select(OrderSearchConverter.EntityToApi).ToList()
                            : new List<OrderSearchView>(),
                        order = booking.Order != null
                            ? orders != null
                                ? OrderSearchConverter.EntityToApi(orders.FirstOrDefault())
                                : new OrderSearchView()
                            : new OrderSearchView(),
                        table = new TableSearchView(),
                        user = booking.User != null
                            ? new UserSearchView
                            {
                                id = booking.User.Id,
                                modificationCounter = 0,
                                revision = null,
                                email = booking.Email,
                                password = null,
                                userRoleId = booking.User.IdRole,
                                username = booking.User.UserName
                            }
                            : new UserSearchView()
                    });
                }
            }
            catch (Exception ex)
            {
                var msg = $"{ex.Message} : {ex.InnerException}";
            }

            return result;
        }


        public List<OrderSearchFullResponseView> GetBookinSearchFullResponse(string bookingToken, string email)
        {
            var result = new List<OrderSearchFullResponseView>();
            
            try
            {
                List<Order> orderList;

                #region orders from common booking
                //search through common booking
                var commonbookingList = _bookingRepository.GetAll(b => b.IdBookingType == 0);                
                foreach (var booking in commonbookingList)
                {
                    orderList = _orderRepository.GetAll(o=>o.IdReservation == booking.Id).ToList();
                    result.AddRange(GetOrderSearchFullResponseViewList(booking, orderList));
                }
                #endregion

                #region orders from invited guest
                //search through invited
                var invitedList = GetInvitedFromToken(bookingToken);
                foreach (var invitedItem in invitedList)
                {
                    var idBooking = invitedItem.IdBooking;
                    var booking = _bookingRepository.Get(b => b.Id == idBooking);
                    orderList = _orderRepository.GetAll(o => o.IdInvitationGuest == idBooking || o.IdReservation == idBooking).ToList();
                    result.AddRange(GetOrderSearchFullResponseViewList(booking, orderList));
                }
                #endregion

            }
            catch (Exception ex)
            {
                var msg = $"{ex.Message} : {ex.InnerException}";
            }

            return result;

        }

        public BookingResponseView CreateReservationAndGuestList(int bookingViewType, string bookingViewName, int reservationViewAssistants, List<string> reservationViewGuestList, string reservationViewEmail, DateTime reservationViewDate, long? userId)
        {
            var reservation = CreateReservation(bookingViewType, bookingViewName, reservationViewAssistants, reservationViewEmail, reservationViewDate, userId);
            CreateInvitationGuests(reservation.Id, reservationViewGuestList, reservationViewEmail);
            _unitOfWork.Commit();
            return new BookingResponseView
            {
                Id = reservation.Id,
                Name = reservation.Name,
                Assistants = reservation.Assistants,
                Email = reservation.Email,
                BookingType = reservation.IdBookingType != null ? reservation.IdBookingType.Value.ToString() : "0",
                BookingDate = JsonConvert.SerializeObject(reservation.BookingDate), //Convert.ToInt64(reservation.BookingDate),
                ModificationCounter = 0,
                BookingToken = reservation.ReservationToken,
                Canceled = reservation.Canceled ?? false,
                Comment = reservation.Comments,
                CreationDate = JsonConvert.SerializeObject(reservation.CreationDate),
                ExpirationDate = JsonConvert.SerializeObject(reservation.ExpirationDate),
                OrderId = reservation.Order,
                Revision = null,
                TableId = reservation.TableId,
                UserId = reservation.UserId
            };
        }

        public EmailResponseView AcceptOrRejectInvitationGuest(string bookingToken, bool accepted)
        {

            var invitedGuest = _invitedGuestRepository.Get(i => i.GuestToken == bookingToken);
            if (invitedGuest == null) return null;
            invitedGuest.ModificationDate = DateTime.UtcNow.ToLocalTime();
            invitedGuest.Accepted = accepted;

            _invitedGuestRepository.Save();
            _unitOfWork.Commit();
            return new EmailResponseView
            {
                id = invitedGuest.Id,
                revision = null,
                modificationCounter = 0,
                guestToken = invitedGuest.GuestToken,
                accepted = invitedGuest.Accepted.Value,
                modificationDate = invitedGuest.ModificationDate,
                bookingId = invitedGuest.IdBooking,
                email = invitedGuest.Email
            };
        }

        #region private methods

        private List<Order> GetBookingOrder(long bookingId)
        {
            var result = _orderRepository.GetAll(o => o.IdInvitationGuest == bookingId || o.IdReservation == bookingId)
                .ToList();
            foreach (var order in result)
            {
                order.OrderLine = _orderLineRepository.GetAll(l => l.IdOrder == order.Id).ToList();
            }

            return result;
        }

        private List<InvitedGuest> GetInvited(long bookingId)
        {
            return _invitedGuestRepository.GetAll(o => o.IdBooking == bookingId || o.IdBooking == bookingId).ToList();
        }

        private List<InvitedGuest> GetInvitedFromToken(string token)
        {
            return string.IsNullOrEmpty(token)
                ? _invitedGuestRepository.GetAll().ToList()
                : _invitedGuestRepository.GetAll(o => o.GuestToken.ToLower().Contains(token.ToLower())).ToList();
        }

        private InvitedguestFullResponse GetInvitedguestFullResponse(InvitedGuest invitedGuest)
        {
            if (invitedGuest == null) return new InvitedguestFullResponse();
            return new InvitedguestFullResponse
            {
                id = invitedGuest.Id,
                revision = 0,
                modificationCounter = 0,
                email = invitedGuest.Email,
                accepted = invitedGuest.Accepted ?? false,
                guestToken = invitedGuest.GuestToken,
                bookingId = invitedGuest.IdBooking,
                modificationDate = JsonConvert.SerializeObject(invitedGuest.ModificationDate)

            };
        }

        private OrderFullResponse GetOrderFullResponse(InvitedGuest invitedGuest, long orderId)
        {
            if (invitedGuest == null) return new OrderFullResponse { id = orderId };
            return new OrderFullResponse
            {
                id = orderId,
                revision = null,
                modificationCounter = 0,
                bookingToken = invitedGuest.GuestToken,
                bookingId = invitedGuest.IdBooking,
                hostId = null,
                invitedGuestId = invitedGuest.Id
            };
        }


        private List<OrderSearchFullResponseView> GetOrderSearchFullResponseViewList(Booking booking, List<Order> orderList)
        {
            return (from orderItem in orderList
                select orderItem.Id
                into orderId
                let order = _orderRepository.Get(o => o.Id == orderId)
                let orderLineitems = _orderLineRepository.GetAll(o => o.IdOrder == orderId)
                select new OrderSearchFullResponseView
                {
                    booking = BookingConverter.EntityToApiFullResponse(booking),
                    invitedGuest = GetInvitedguestFullResponse(null),
                    order = GetOrderFullResponse(null, order.Id),
                    orderLines = orderLineitems.Select(OrderLineConverter.EntityToApi).ToList(),
                    host = new HostFullResponse()
                }).ToList();
        }


        private Booking CreateReservation(int bookingViewType, string reservationViewName, int reservationAssistants, string reservationViewEmail, DateTime reservationViewDate,
            long? userId)
        {
            var bookingTypeStringToken = bookingViewType == 0
                ? BookingTypeConst.CommonBooking
                : BookingTypeConst.GuestBooking;

            var reservation = new Booking
            {
                Name = reservationViewName,
                IdBookingType = bookingViewType,
                BookingDate = Convert.ToDateTime(reservationViewDate),
                Canceled = false,
                CreationDate = DateTime.Now,
                UserId = userId,
                ReservationToken = GetReservationToken(bookingTypeStringToken, reservationViewEmail),
                Assistants = reservationAssistants,
                ExpirationDate = Convert.ToDateTime(reservationViewDate).AddHours(-1),
                Email = reservationViewEmail
            };

            _bookingRepository.Create(reservation);
            _bookingRepository.Save();
            _unitOfWork.Commit();
            return reservation;
        }

        private string GetReservationToken(string reservationTypeString, string userEmail)
        {
            //{(CRS_|GRS_)}{now.Year}{now.Month:00}{now.Day:00}{_}{MD5({Guest-email}{now.Year}{now.Month:00}{now.Day:00}{now.Hour:00}{now.Minute:00}{now.Second:00})}
            var now = DateTime.Now;
            var md5Token = $"{userEmail}{now.Year}{now.Month:00}{now.Day:00}{now.Hour:00}{now.Minute:00}{now.Second:00}"
                .Md5Encode();
            return $"{reservationTypeString}_{now.Year}{now.Month:00}{now.Day:00}_{md5Token.ToLower()}".Replace("-",
                string.Empty);
        }

        private void CreateInvitationGuests(long bookingId, List<string> guestList, string userEmail)
        {

            foreach (var mail in guestList)
            {
                _invitedGuestRepository.Create(new InvitedGuest()
                {
                    IdBooking = bookingId,
                    Email = mail,
                    Accepted = null,
                    ModificationDate = DateTime.Now,
                    GuestToken = GetReservationToken(BookingTypeConst.GuestBooking, userEmail)

                });
                _invitedGuestRepository.Save();
            }
            _unitOfWork.Commit();


        }

        #endregion
    }
}
