﻿using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace Oasp4Net.Application.WebApi
{
    public class Program
    {
        private static string AppPath = Directory.GetCurrentDirectory() + @"\Application\WebApi\";        
        public static IConfigurationRoot Configuration { get; set; }
        public static void Main(string[] args)
        {
            Configure();
            var urlHost = $"http://*:{Configuration["LocalListenPort"]}";
            var host = new WebHostBuilder()
                .UseKestrel()
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseStartup<Startup>()
                .UseApplicationInsights()
                .UseUrls(urlHost)
                .Build();

            host.Run();
        }

        public static void Configure()
        {
            var builder = new ConfigurationBuilder().SetBasePath(AppPath)
                .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
        }
    }
}
