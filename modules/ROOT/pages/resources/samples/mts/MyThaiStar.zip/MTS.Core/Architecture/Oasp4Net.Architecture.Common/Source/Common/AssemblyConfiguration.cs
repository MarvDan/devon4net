﻿namespace Oasp4Net.Architecture.Common.Source.Common
{
    public class ReferencedAssemblyConfiguration
    {
        public char SeparatorChar { get; set; }
        public string ReferencedAssemblies { get; set; }
    }
}