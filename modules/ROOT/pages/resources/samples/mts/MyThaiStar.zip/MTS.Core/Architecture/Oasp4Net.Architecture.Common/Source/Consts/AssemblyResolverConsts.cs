﻿namespace Oasp4Net.Architecture.Common.Source.Consts
{
    public class AssemblyResolverConsts
    {
        public const string ControllerAssemblies = "ControllerAssemblies";
    }
}