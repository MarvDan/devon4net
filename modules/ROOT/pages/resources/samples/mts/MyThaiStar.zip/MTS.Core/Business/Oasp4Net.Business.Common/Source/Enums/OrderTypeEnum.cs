﻿namespace Oasp4Net.Business.Common.Source.Enums
{
    public enum OrderTypeEnum
    {        
        CommonBooking = 0,
        GuestBooking = 1
    }

}
