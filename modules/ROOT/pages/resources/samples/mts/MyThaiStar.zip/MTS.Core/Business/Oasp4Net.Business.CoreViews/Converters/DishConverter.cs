﻿using System;
using System.Collections.Generic;
using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Business.CoreViews.Views.Dish;

namespace Oasp4Net.Business.CoreViews.Converters
{
    /// <summary>
    /// 
    /// </summary>
    public class DishConverter
    {
        /// <summary>
        /// Transforms entity object to view object
        /// </summary>
        /// <param name="item">Entity item to be transformed to api view</param>
        /// <returns>API view</returns>
        public static DishViewResult EntityToApi(Dish item)
        {
            if (item == null) return null;

            return new DishViewResult
            {
                dish = DishToApi(item),
                categories = GetDishCategories(item.DishCategory),
                extras = GetDishExtras(item.DishIngredient),
                image = GetImageViewFromImage(item.IdImageNavigation)
            };
        }

        private static List<ExtraView> GetDishExtras(ICollection<DishIngredient> itemDishIngredient)
        {
            var result = new List<ExtraView>();

            if (itemDishIngredient == null) return result;

            try
            {
                foreach (var item in itemDishIngredient)
                {
                    result.Add(new ExtraView
                    {
                        id = item.IdIngredient,
                        description = item.IdIngredientNavigation.Description,
                        price = item.IdIngredientNavigation.Price,
                        modificationCounter = item.ModificationCounter,
                        revision = 1,
                        name = item.IdIngredientNavigation.Name
                    });
                }
            }
            catch (Exception ex)
            {
                var msg = $"{ex.Message} : {ex.InnerException}";
            }

            return result;
        }

        private static List<CategoryView> GetDishCategories(ICollection<DishCategory> itemDishCategory)
        {
            var result = new List<CategoryView>();

            if (itemDishCategory == null) return result;

            try
            {
                foreach (var item in itemDishCategory)
                {
                    result.Add(new CategoryView
                    {
                        id = item.IdCategory,
                        description = item.IdCategoryNavigation.Description,
                        modificationCounter = item.IdCategoryNavigation.ModificationCounter,
                        revision = 1,
                        name = item.IdCategoryNavigation.Name,
                        showOrder = item.IdCategoryNavigation.ShowOrder
                    });

                }
            }
            catch (Exception ex)
            {
                var msg = $"{ex.Message} : {ex.InnerException}";
            }

            return result;
        }

        private static DishView DishToApi(Dish item)
        {
            return new DishView
            {
                id = item.Id,
                description = item.Description,
                name = item.Name,
                price = item.Price,
                imageId = item.IdImage,
                modificationCounter = 0
            };
        }

        private static ImageView GetImageViewFromImage(Image image)
        {
            if (image==null) return new ImageView();
            var result = new ImageView();
            
            try
            {
                result = new ImageView
                {
                    content = image.Content,
                    modificationCounter = image.ModificationCounter,
                    mimeType = image.MimeType,
                    name = image.Name,
                    id = image.Id,
                    contentType = image.ContentType == 0 ? "Binary" : "Url",
                    revision = 1
                };
            }
            catch (Exception ex)
            {
                var msg = $"{ex.Message} : {ex.InnerException}";
            }


            return result;
        }        
    }
}
