﻿using Oasp4net.DataAccessLayer.Common.Interfaces;
using Oasp4net.DataAccessLayer.Models;

namespace Oasp4net.DataAccess.Repositories.Interfaces
{
    public interface IOrderLineRepository : IRepository<OrderLine>
    {
    }
}
