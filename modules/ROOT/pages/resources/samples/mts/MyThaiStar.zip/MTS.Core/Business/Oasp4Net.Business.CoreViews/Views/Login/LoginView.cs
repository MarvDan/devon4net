﻿using Newtonsoft.Json;

namespace Oasp4Net.Business.CoreViews.Views.Login
{
    public class LoginView
    {
        [JsonProperty(PropertyName = "username")]
        public string UserName { get; set; }
        [JsonProperty(PropertyName = "password")]
        public string Password { get; set; }
    }
}
