﻿using System.Collections.Generic;

namespace Oasp4net.DataAccessLayer.Models
{
    public partial class Order
    {
        public Order()
        {
            OrderLine = new HashSet<OrderLine>();
        }

        public long Id { get; set; }
        public long? IdReservation { get; set; }
        public long? IdInvitationGuest { get; set; }

        public InvitedGuest IdInvitationGuestNavigation { get; set; }
        public Booking IdReservationNavigation { get; set; }
        public ICollection<OrderLine> OrderLine { get; set; }
    }
}
