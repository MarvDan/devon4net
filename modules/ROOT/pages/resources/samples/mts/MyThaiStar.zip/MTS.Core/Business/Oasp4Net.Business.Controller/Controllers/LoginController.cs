﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Oasp4Net.Business.CoreViews.Views.Login;
using Oasp4Net.Business.Service.LoginService.Interface;
using Oasp4Net.Infrastructure.JWT;

namespace Oasp4NetCore.Business.Controller.Controllers
{
    [EnableCors("CorsPolicy")]

    public class LoginController : Microsoft.AspNetCore.Mvc.Controller
    {
        private readonly ILogger<LoginController> _logger;
        private readonly JwtOptions _jwtOptions;
        private readonly ILoginService _loginService;
        private readonly JsonSerializerSettings _serializerSettings;        
        private readonly SignInManager<ApplicationUser> _signInManager;

        public LoginController(ILoginService service, IOptions<JwtOptions> jwtOptions, ILogger<LoginController> logger, SignInManager<ApplicationUser> signInManager)
        {
            _logger = logger;
            _loginService = service;
            _jwtOptions = jwtOptions.Value;
            _signInManager = signInManager;
            ThrowIfInvalidOptions(_jwtOptions);

            _serializerSettings = new JsonSerializerSettings
            {
                Formatting = Formatting.None
            };
        }

        [HttpGet]
        [HttpOptions]
        [Route("/mythaistar/services/rest/security/v1/currentuser")]
        [AllowAnonymous]
        [EnableCors("CorsPolicy")]
        public IActionResult CurrentUser()
        {

            var jwtUser = HttpContext.User.Claims;
            _logger.LogInformation($"jwtUser count: {jwtUser.Count()}");


            CurrentUserView result;

            try
            {
                if (jwtUser != null)
                {
                    var userEasyName = ControllerContext.HttpContext.User.Identity.Name;
                    _logger.LogInformation($"userEasyName: {userEasyName}");

                    result = new CurrentUserView
                    {
                        Name = userEasyName,
                        Role = userEasyName.ToLower().Contains("waiter") ? "WAITER" : "CUSTOMER",
                        Id = null,
                        FirstName = null,
                        LastName = null
                    };
                }
                else
                {
                    result = new CurrentUserView();
                }
            }
            catch (Exception ex)
            {
                _logger.LogDebug($"{ex.Message} : {ex.InnerException}");
                result = new CurrentUserView();
            }

            var json = JsonConvert.SerializeObject(result, _serializerSettings);
            return Ok(json);
            //return new OkObjectResult(json);
        }

        /// <summary>
        /// Gets the  list of available dishes regarding the filter options
        /// </summary>
        /// <param name="loginView"></param>
        /// <returns></returns>
        /// <response code="200"> Ok. </response>
        /// <response code="401">Unathorized. Autentication fail</response>  
        /// <response code="403">Forbidden. Authorization error.</response>    
        /// <response code="500">Internal Server Error. The search process ended with error.</response>       
        [HttpPost]
        [HttpOptions]
        [Route("/mythaistar/login")]
        [AllowAnonymous]
        [EnableCors("CorsPolicy")]
        public async Task<IActionResult> Login([FromBody]LoginView loginView)
        {
            try
            {
                if (loginView == null) return Ok();
                var identity = GetClaimsIdentity(loginView);
                if (identity == null)
                {
                    return BadRequest("Invalid credentials");
                }
                var loged = _loginService.Login(loginView.UserName, loginView.Password);
                if (loged)
                {
                    var userScope = _loginService.GetUserScope(loginView.UserName);
                    if (!string.IsNullOrEmpty(userScope))
                    {
                        var now = new DateTimeOffset(DateTime.UtcNow);
                        var claims = new[]
                        {
                            new Claim(JwtConst.ClaimIssuer, JwtConst.Issuer),
                            new Claim(JwtRegisteredClaimNames.Sub, loginView.UserName),
                            new Claim(JwtConst.ClaimScope, userScope),
                            new Claim(JwtConst.ClaimCreated,now.ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64),
                            new Claim(JwtConst.ClaimExpiration,now.AddMinutes(60).ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64),
                            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                            new Claim(JwtRegisteredClaimNames.Iat, now.ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64)
                        };

                        // Create the JWT security token and encode it.
                        var jwt = new JwtSecurityToken(
                            issuer: _jwtOptions.Issuer,
                            audience: _jwtOptions.Audience,
                            claims: claims,
                            notBefore: _jwtOptions.NotBefore,
                            expires: _jwtOptions.Expiration.AddHours(5),
                            signingCredentials: _jwtOptions.SigningCredentials);

                        var encodedJwt = new JwtSecurityTokenHandler().WriteToken(jwt);

                        var result = await _signInManager.PasswordSignInAsync(loginView.UserName, "*Dev0nMts2017", true, lockoutOnFailure: false);
                        if (!result.Succeeded) return StatusCode((int)HttpStatusCode.Unauthorized, "Login Error");
                        Response.Headers.Add("Access-Control-Expose-Headers", "Authorization");
                        Response.Headers.Add("X-Content-Type-Options", "nosniff");
                        Response.Headers.Add("X-Frame-Options", "DENY");
                        Response.Headers.Add("X-XSS-Protection", "1;mode=block");
                        Response.Headers.Add("X-Application-Context", "restaurant:h2mem:8081");
                        Response.Headers.Add("Authorization", $"{JwtConst.TokenPrefix} {encodedJwt}");

                        return Ok(encodedJwt);
                    }
                }
                Response.Headers.Clear();
                return StatusCode((int)HttpStatusCode.Unauthorized, "Login Error");
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, $"{ex.Message} : {ex.InnerException}");
            }
        }


        #region private methods
        private static void ThrowIfInvalidOptions(JwtOptions options)
        {
            if (options == null) throw new ArgumentNullException(nameof(options));

            if (options.ValidFor <= TimeSpan.Zero)
            {
                throw new ArgumentException("Must be a non-zero TimeSpan.", nameof(JwtOptions.ValidFor));
            }

            if (options.SigningCredentials == null)
            {
                throw new ArgumentNullException(nameof(JwtOptions.SigningCredentials));
            }

            if (options.JtiGenerator == null)
            {
                throw new ArgumentNullException(nameof(JwtOptions.JtiGenerator));
            }
        }

        private static Task<ClaimsIdentity> GetClaimsIdentity(LoginView user)
        {
            if (user == null) return Task.FromResult<ClaimsIdentity>(null);
            if (user.UserName == "waiter" &&
                user.Password == "waiter")
            {
                return Task.FromResult(new ClaimsIdentity(new GenericIdentity(user.UserName, "Token"),
                    new[]
                    {
                        new Claim("MTSWaiter", "waiter")
                    }));
            }

            if (user.UserName == "user0" &&
                user.Password == "password")
            {
                return Task.FromResult(new ClaimsIdentity(new GenericIdentity(user.UserName, "Token"),
                    new[]
                    {
                        new Claim("MTSCustomer", "customer")
                    }));
            }

            // Credentials are invalid, or account doesn't exist
            return Task.FromResult<ClaimsIdentity>(null);
        }
        #endregion
    }
}
