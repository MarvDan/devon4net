﻿using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Business.CoreViews.Views;
using Oasp4Net.Business.CoreViews.Views.Booking;

namespace Oasp4Net.Business.CoreViews.Converters
{
    public class OrderSearchConverter
    {
        public static OrderSearchView EntityToApi(Order item)
        {
            if (item == null) return new OrderSearchView();

            return new OrderSearchView
            {
                id = item.Id,
                revision = null,
                modificationCounter = 0,
                bookingToken = item.IdReservationNavigation.ReservationToken,
                bookingId = item.IdReservationNavigation.Id,
                hostId = null,
                invitedGuestId = item.IdInvitationGuest
            };

        }

    }
}