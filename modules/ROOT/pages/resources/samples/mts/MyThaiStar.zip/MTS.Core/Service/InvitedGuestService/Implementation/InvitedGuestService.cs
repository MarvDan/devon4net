﻿using Oasp4net.DataAccessLayer.Common.Implementation;
using Oasp4net.DataAccessLayer.Common.Interfaces;
using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Business.Service.InvitedGuestService.Interface;


namespace Oasp4Net.Business.Service.InvitedGuestService.Implementation
{
    public class InvitedGuestService : EntityService<InvitedGuest>, IInvitedGuestService
    {
        public InvitedGuestService(IUnitOfWork unitOfWork, IRepository<InvitedGuest> repository) : base(unitOfWork, repository)
        {
        }
    }
}
