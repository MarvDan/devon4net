﻿
namespace Oasp4Net.Business.Common.Source.Enums
{
    public enum EmailTypeEnum
    {
        CreateBooking,
        InvitedGuest,
        InvitedHost,
        Order
    }
}
