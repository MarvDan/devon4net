﻿using System;
using System.Collections.Generic;
using Oasp4Net.Business.CoreViews.Views.Booking;
using Oasp4Net.Business.CoreViews.Views.Email;
using Oasp4Net.Business.CoreViews.Views.Order;

namespace Oasp4Net.Business.Service.BookingService.Interface
{
    public interface IBookingService
    {
        List<BookingSearchResponse> GetBookingSearch(string bookingToken, string email);
        List<OrderSearchFullResponseView> GetBookinSearchFullResponse(string bookingToken, string email);
        BookingResponseView CreateReservationAndGuestList(int bookingViewType, string reservationViewName, int reservationViewAssistants, List<string> reservationViewGuestList, string reservationViewEmail, DateTime reservationViewDate, long? userId);
        EmailResponseView AcceptOrRejectInvitationGuest(string bookingToken, bool accepted);
    }
}
