﻿using System.Collections.Generic;

namespace Oasp4Net.Business.CoreViews.Views.Order
{
    public class OrderView
    {
        public OrderViewBooking booking { get; set; }
        public List<OrderlineView> orderLines { get; set; }
    }

    public class OrderViewBooking
    {
        public string bookingToken { get; set; }
    }

    public class OrderlineView
    {
        public OrderlineViewDetail orderLine { get; set; }
        public Extra[] extras { get; set; }
    }

    public class OrderlineViewDetail
    {
        public int dishId { get; set; }
        public int amount { get; set; }
        public string comment { get; set; }
    }

    public class Extra
    {
        public long id { get; set; }
    }



    public class OrderViewResponse
    {
        public int id { get; set; }
        public int modificationCounter { get; set; }
        public object revision { get; set; }
        public int bookingId { get; set; }
        public object invitedGuestId { get; set; }
        public object bookingToken { get; set; }
        public object hostId { get; set; }
    }


}
