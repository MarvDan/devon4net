﻿using System.Collections.Generic;

namespace Oasp4Net.Business.CoreViews.Views.Booking
{


    public class BookingSearchResponse
    {
        public BookingSearchResponseView booking { get; set; }
        public TableSearchView table { get; set; }
        public List<InvitedguestSearchView> invitedGuests { get; set; }
        public OrderSearchView order { get; set; }
        public List<OrderSearchView> orders { get; set; }
        public UserSearchView user { get; set; }
    }

    public class BookingSearchResponseView
    {
        public long id { get; set; }
        public int modificationCounter { get; set; }
        public object revision { get; set; }
        public string name { get; set; }
        public string bookingToken { get; set; }
        public string comment { get; set; }
        public string bookingDate { get; set; }
        public string expirationDate { get; set; }
        public string creationDate { get; set; }
        public string email { get; set; }
        public bool canceled { get; set; }
        public string bookingType { get; set; }
        public long? tableId { get; set; }
        public long? orderId { get; set; }
        public int? assistants { get; set; }
        public long? userId { get; set; }
    }

    public class TableSearchView
    {
        public int id { get; set; }
        public int modificationCounter { get; set; }
        public int? revision { get; set; }
        public int seatsNumber { get; set; }
    }

    public class OrderSearchView
    {
        public long id { get; set; }
        public int modificationCounter { get; set; }
        public int? revision { get; set; }
        public long? bookingId { get; set; }
        public long? invitedGuestId { get; set; }
        public object bookingToken { get; set; }
        public long? hostId { get; set; }
    }

    public class UserSearchView
    {
        public long id { get; set; }
        public int modificationCounter { get; set; }
        public int? revision { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string email { get; set; }
        public long userRoleId { get; set; }
    }

    public class InvitedguestSearchView
    {
        public long id { get; set; }
        public int modificationCounter { get; set; }
        public int? revision { get; set; }
        public long bookingId { get; set; }
        public string guestToken { get; set; }
        public string email { get; set; }
        public bool accepted { get; set; }
        public string modificationDate { get; set; }
    }

    //public class OrderInvitedSearchView
    //{
    //    public long id { get; set; }
    //    public int modificationCounter { get; set; }
    //    public object revision { get; set; }
    //    public long bookingId { get; set; }
    //    public long? invitedGuestId { get; set; }
    //    public object bookingToken { get; set; }
    //    public int? hostId { get; set; }
    //}

}