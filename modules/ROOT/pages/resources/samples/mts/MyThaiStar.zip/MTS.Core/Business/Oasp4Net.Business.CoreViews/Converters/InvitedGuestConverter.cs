﻿using Newtonsoft.Json;
using Oasp4net.DataAccessLayer.Models;
using Oasp4Net.Business.CoreViews.Views.Booking;

namespace Oasp4Net.Business.CoreViews.Converters
{
    public class InvitedGuestConverter
    {
        public static InvitedguestSearchView EntityToApi(InvitedGuest item)
        {
            if (item == null) return new InvitedguestSearchView();

            return new InvitedguestSearchView
            {
                id = item.Id,
                revision = null,
                modificationCounter = 0,
                email = item.Email,
                accepted = item.Accepted ?? false,
                guestToken = item.GuestToken,
                bookingId = item.IdBooking,
                modificationDate = JsonConvert.SerializeObject(item.ModificationDate)
            };

        }

        public static InvitedguestSearchView EntityToApiFullResponse(InvitedGuest item)
        {
            if (item == null) return new InvitedguestSearchView();

            return new InvitedguestSearchView
            {
                id = item.Id,
                revision = null,
                modificationCounter = 0,
                email = item.Email,
                accepted = item.Accepted ?? false,
                guestToken = item.GuestToken,
                bookingId = item.IdBooking,
                modificationDate = JsonConvert.SerializeObject(item.ModificationDate)
            };

        }

    }
}