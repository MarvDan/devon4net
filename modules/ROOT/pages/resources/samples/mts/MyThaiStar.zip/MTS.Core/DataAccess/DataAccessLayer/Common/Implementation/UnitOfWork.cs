﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Storage;
using Oasp4net.DataAccessLayer.Common.Interfaces;

namespace Oasp4net.DataAccessLayer.Common.Implementation
{
    public class UnitOfWork : IUnitOfWork
    {
        private ModelContext DbContext { get; }
        private IDbContextTransaction Transaction { get; set; }
        private bool Disposed { get; set; }

        public UnitOfWork(ModelContext context)
        {
            DbContext = context;
            Transaction = DbContext.Database.BeginTransaction();
        }



        #region async methods
        public async Task<int> CommitAsync()
        {
            int result;
            try
            {
                result = await DbContext.SaveChangesAsync();
                Transaction.Commit();
            }
            catch
            {
                Transaction.Rollback();
                throw;
            }
            finally
            {
                Transaction = DbContext.Database.BeginTransaction();
            }

            return result;
        }

        #endregion

        #region sync methods
        public int Commit()
        {
            int result;
            try
            {
                result = DbContext.SaveChanges();
                Transaction.Commit();
            }
            catch
            {
                Transaction.Rollback();
                throw;
            }
            finally
            {
                Transaction = DbContext.Database.BeginTransaction();
            }

            return result;
        }
        #endregion

        
        protected virtual void Dispose(bool disposing)
        {
            if (!Disposed)
            {
                if (disposing)
                {
                    Transaction.Dispose();
                    DbContext.Dispose();
                }
            }
            Disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

    }
}
