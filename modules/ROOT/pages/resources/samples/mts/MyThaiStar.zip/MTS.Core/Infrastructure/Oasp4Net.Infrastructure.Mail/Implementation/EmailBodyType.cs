namespace Oasp4Net.Infrastructure.CrossCutting.CoreMailing.Implementation
{
    public enum EmailBodyType
    {
        PlainText,
        HtmlText
    }
}